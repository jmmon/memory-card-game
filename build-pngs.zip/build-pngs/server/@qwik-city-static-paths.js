const staticPaths = new Set(["/cards/0C.svg","/cards/0D.svg","/cards/0H.svg","/cards/0S.svg","/cards/2C.svg","/cards/2D.svg","/cards/2H.svg","/cards/2S.svg","/cards/3C.svg","/cards/3D.svg","/cards/3H.svg","/cards/3S.svg","/cards/4C.svg","/cards/4D.svg","/cards/4H.svg","/cards/4S.svg","/cards/5C.svg","/cards/5D.svg","/cards/5H.svg","/cards/5S.svg","/cards/6C.svg","/cards/6D.svg","/cards/6H.svg","/cards/6S.svg","/cards/7C.svg","/cards/7D.svg","/cards/7H.svg","/cards/7S.svg","/cards/8C.svg","/cards/8D.svg","/cards/8H.svg","/cards/8S.svg","/cards/9C.svg","/cards/9D.svg","/cards/9H.svg","/cards/9S.svg","/cards/AC.svg","/cards/AD.svg","/cards/AH.svg","/cards/AS (2).svg","/cards/AS.svg","/cards/JC.svg","/cards/JD.svg","/cards/JH.svg","/cards/JS.svg","/cards/KC.svg","/cards/KD.svg","/cards/KH.svg","/cards/KS.svg","/cards/QC.svg","/cards/QD.svg","/cards/QH.svg","/cards/QS.svg","/cards/_back1B.svg","/cards/_back2B.svg","/cards/_backWhite.svg","/cards/_joker1J.svg","/cards/_joker2J.svg","/favicon.svg","/fonts/poppins-400.woff2","/fonts/poppins-500.woff2","/fonts/poppins-700.woff2","/manifest.json","/q-manifest.json","/robots.txt","/service-worker.js","/sitemap.xml"]);
function isStaticPath(method, url) {
  if (method.toUpperCase() !== 'GET') {
    return false;
  }
  const p = url.pathname;
  if (p.startsWith("/build/")) {
    return true;
  }
  if (p.startsWith("/assets/")) {
    return true;
  }
  if (staticPaths.has(p)) {
    return true;
  }
  if (p.endsWith('/q-data.json')) {
    const pWithoutQdata = p.replace(/\/q-data.json$/, '');
    if (staticPaths.has(pWithoutQdata + '/')) {
      return true;
    }
    if (staticPaths.has(pWithoutQdata)) {
      return true;
    }
  }
  return false;
}
export { isStaticPath };