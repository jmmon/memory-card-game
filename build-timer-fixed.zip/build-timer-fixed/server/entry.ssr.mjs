import"./assets/@qwik-city-plan-445f6fc6.mjs";import{r as p}from"./assets/entry.ssr-8b232a99.mjs";import"jabber";export{p as default};
