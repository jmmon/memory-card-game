import"./assets/@qwik-city-plan-36c845a7.mjs";import{r as p}from"./assets/entry.ssr-1024286e.mjs";import"jabber";export{p as default};
